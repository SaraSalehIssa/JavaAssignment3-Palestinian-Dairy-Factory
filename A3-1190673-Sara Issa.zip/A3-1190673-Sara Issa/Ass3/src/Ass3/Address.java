package Ass3;

public class Address {

	// Data fields
	private String street;
	private String state;
	private String city;
	private String zipCode;

	// Constructors and methods
	public Address() {
		this.street = "SalahAl-ddin";
		this.state = "Jerusalem";
		this.setCity("Palestine"); // this.city = "Palestine";
		this.zipCode = "000";
	}

	public Address(String street, String state, String city, String zipCode) {
		this.street = street;
		this.state = state;
		this.setCity(city); // this.city = city;
		this.zipCode = zipCode;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	// To check if the factory is a Palestinian factory
	public void setCity(String city) {
		if (city != "Palestine" && city != "palestine") {
			System.out.println("This factory is not a Palestinian factory");
		}
		this.city = city;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	@Override
	public String toString() {
		return "Address [street=" + street + ", state=" + state + ", city=" + city + ", zipCode=" + zipCode + "]";
	}

}

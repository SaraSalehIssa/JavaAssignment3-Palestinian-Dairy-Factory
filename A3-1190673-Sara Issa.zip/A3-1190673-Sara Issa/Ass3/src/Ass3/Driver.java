package Ass3;

import java.util.ArrayList;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// To make ArrayList should have at least 2 types from every subclass
		ArrayList<Employee> employee = new ArrayList<Employee>();
		Employee e1 = new ProductionWorker("Ahmad", "000-a", 119, 12, 1, new Address(), 1, 12, 220);
		Employee e2 = new ProductionWorker("Mohammad", "001-M", 118, 3, 23, new Address("Eyan Sara street", "Hebron", "Palestine", "000"), 2, 13, 200);
		Employee e3 = new ShiftSupervisor("Bayan", "010-B", 117, 7, 10, new Address(), 2400, 100, 5, 7);
		Employee e4 = new ShiftSupervisor("Eman", "011-E", 116, 8, 8, new Address("Rafidia street", "Nablus", "Palestine", "001"), 8000, 150, 8, 10);
		Employee e5 = new TeamLeader("Ali", "100-A", 115, 3, 7, new Address(), 1, 14, 100, 90, 8, 10);
		Employee e6 = new TeamLeader("Haneen", "101-H", 114, 6, 4, new Address("Rukab street", "Ramallah", "Palestine", "010"), 2, 15, 250, 93, 10, 10);
		
		// Entering values into ArrayList and increasing it's size
		employee.add(e1);
		employee.add(e2);
		employee.add(e3);
		employee.add(e4);
		employee.add(e5);
		employee.add(e6);

		// To print employee information
		for (int index = 0; index < employee.size(); index++) {
			if (employee.get(index).isEmpNumberValid()) {
				if ((employee.get(index) instanceof ProductionWorker) || (employee.get(index) instanceof TeamLeader)) {
					if (((ProductionWorker) employee.get(index)).isAvailable()) {
						System.out.println("Employee information is: " + employee.get(index).toString());
					} else {
						System.out.println("This employee isn't available due to the incorrect condition: "
								+ employee.get(index).toString());
					}
				} else if (employee.get(index) instanceof ShiftSupervisor) {
					if (((ShiftSupervisor) employee.get(index)).isNonNegativeMonnthlySalary()) {
						System.out.println("Employee information is: " + employee.get(index).toString());
					} else {
						System.out.println("This employee isn't available due to the incorrect condition: "
								+ employee.get(index).toString());
					}
				}
			} else {
				System.out.println("This employee isn't available due to the incorrect condition: "
						+ employee.get(index).toString());
			}
		}

		// Calling method
		System.out.println("  ");
		System.out.println("Employee whose salary is higher than the average:");
		ListGreaterThanAverage(employee);
	}

	// Method to print Salaries are higher than average employee salaries
	public static void ListGreaterThanAverage(ArrayList<Employee> list) {
		double salary = 0, average = 0;
		int index = 0, numberOfEmployee = 0;

		while (index < list.size()) {
			if (list.get(index).isEmpNumberValid()) {
				if (list.get(index) instanceof ProductionWorker) {
					if (((ProductionWorker) list.get(index)).isAvailable())
						salary += ((ProductionWorker) list.get(index)).getTotalSalary();
				}

				else if (list.get(index) instanceof ShiftSupervisor) {
					if (((ShiftSupervisor) list.get(index)).isNonNegativeMonnthlySalary()) 
						salary += ((ShiftSupervisor) list.get(index)).getTotalSalary();
				}

				else {
					if (((ProductionWorker) list.get(index)).isAvailable())
						salary += ((TeamLeader) list.get(index)).getTotalSalary();
				}
				// To be use when calculating the rate by dividing total salaries by the number
				// of employees
				numberOfEmployee++;
			}
			index++;
		}
		average = salary / numberOfEmployee;
		for (index = 0; index < list.size(); index++) {
			if (list.get(index).isEmpNumberValid()) {
				if (list.get(index) instanceof ProductionWorker) {
					if (((ProductionWorker) list.get(index)).isAvailable())
						if (((ProductionWorker) list.get(index)).getTotalSalary() > average)
							System.out.println(((ProductionWorker) list.get(index)).toString());
				} else if (list.get(index) instanceof ShiftSupervisor) {
					if (((ShiftSupervisor) list.get(index)).isNonNegativeMonnthlySalary()) 
					if (((ShiftSupervisor) list.get(index)).getTotalSalary() > average)
						System.out.println(((ShiftSupervisor) list.get(index)).toString());
				} else if (list.get(index) instanceof TeamLeader) {
					if (((ProductionWorker) list.get(index)).isAvailable())
						if (((TeamLeader) list.get(index)).getTotalSalary() > average) {
							System.out.println(((TeamLeader) list.get(index)).toString());
						}
				}
			}
		}
	}
}
package Ass3;

public class ProductionWorker extends Employee {

	// Data fields
	private int shift;
	private double hourlyPayRate;
	private double numberOfHoursPerMonth;

	// Constructors and methods
	public ProductionWorker() {
		super();
	}

	public ProductionWorker(String employeeName, String employeeNumber, int year, int month, int day, Address address,
			int shift, double hourlyPayRate, double numberOfHoursPerMonth) {
		super(employeeName, employeeNumber, year, month, day, address);
		this.setShift(shift); // this.shift = shift;
		this.setHourlyPayRate(hourlyPayRate); // this.hourlyPayRate = hourlyPayRate;
		this.setNumberOfHoursPerMonth(numberOfHoursPerMonth); // this.numberOfHoursPerMonth = numberOfHoursPerMonth;
	}

	public int getShift() {
		return shift;
	}

	public void setShift(int shift) {
		this.shift = shift;
	}

	// To check if the employee is available or not [if shift=1 (day shift) or shift=2 (night shift)]
	public boolean isAvailable() {
		if (shift == 1 || shift == 2) {
			return true;
		}
		return false;
	}

	public double getHourlyPayRate() {
		return hourlyPayRate;
	}

	// To check if the hourly rate is a negative number
	public void setHourlyPayRate(double hourlyPayRate) {
		if (this.hourlyPayRate < 0) {
			System.out.println("There is no negative number of hourly pay rate");
		}
		this.hourlyPayRate = hourlyPayRate;
	}

	public double getNumberOfHoursPerMonth() {
		return numberOfHoursPerMonth;
	}

	// To check if the number of hours per month is a negative number
	public void setNumberOfHoursPerMonth(double numberOfHoursPerMonth) {
		if (this.numberOfHoursPerMonth < 0) {
			System.out.println("There is no negative number of hours");
		}
		this.numberOfHoursPerMonth = numberOfHoursPerMonth;
	}

	// @Override
	public double getTotalSalary() {
		double salary = 0;
		// Day shift
		if (this.shift == 1) {
			if (numberOfHoursPerMonth > 208) {
				salary += (208 * hourlyPayRate) + ((numberOfHoursPerMonth - 208) * hourlyPayRate * 1.25);
			}
			salary += numberOfHoursPerMonth * hourlyPayRate;
		}
		// Night shift
		else if (this.shift == 2) {
			if (numberOfHoursPerMonth > 182) {
				salary += (182 * hourlyPayRate) + ((numberOfHoursPerMonth - 182) * hourlyPayRate * 1.5);
			}
			salary += numberOfHoursPerMonth * hourlyPayRate;
		}
		return salary;
	}

	@Override
	public String toString() {
		return "ProductionWorker: " + super.toString() + "shift=" + shift + ", hourlyPayRate=" + hourlyPayRate
				+ ", numberOfHoursPerMonth=" + numberOfHoursPerMonth;
	}

}

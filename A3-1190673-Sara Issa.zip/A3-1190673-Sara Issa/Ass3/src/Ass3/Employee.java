package Ass3;

import java.util.Date;

public class Employee {

	// Data fields
	private String employeeName;
	private String employeeNumber;
	private Date hireDate;
	private Address address;

	// Constructors and methods
	@SuppressWarnings("deprecation")
	public Employee() {
		// Because the number of years starts from 0-120,therefore, an increment of 1900 is required
		this.hireDate = new Date(119, 12, 10);
	}

	@SuppressWarnings("deprecation")
	public Employee(String employeeName, String employeeNumber, int year, int month, int day, Address address) {
		this.employeeName = employeeName;
		this.employeeNumber = employeeNumber;
		this.setHireDate(new Date(year, month, day)); //this.hireDate = new Date(year, month, day);
		this.address = address;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getEmployeeNumber() {
		return employeeNumber;
	}

	public void setEmployeeNumber(String employeeNumber) {
		this.employeeNumber = employeeNumber;
	}

	public Date getHireDate() {
		return hireDate;
	}

	// Determine the employee date requirement
	public void setHireDate(Date hireDate) {
		Date currentDate = new Date();
		if(hireDate == currentDate ) {
			System.out.println("There is no salary before work");
		}
		this.hireDate = hireDate;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	// To check if the employee's number is within the specified conditions or not
	public boolean isEmpNumberValid() {
		if (employeeNumber.length() == 5) {
			if ((employeeNumber.charAt(0) >= '0' && employeeNumber.charAt(0) <= '9')
					&& (employeeNumber.charAt(1) >= '0' && employeeNumber.charAt(1) <= '9')
					&& (employeeNumber.charAt(2) >= '0' && employeeNumber.charAt(2) <= '9')
					&& (employeeNumber.charAt(3) == '-')
					&& (employeeNumber.charAt(4) >= 'A' && employeeNumber.charAt(4) <= 'M')) {
				return true;
			}
		}
		// If the employee number does not meet the conditions
		return false;
	}

	@Override
	public String toString() {
		return "employeeName=" + employeeName + ", employeeNumber=" + employeeNumber + ", hireDate="
				+ getHireDate() + ", address=" + address.toString();
	}

}
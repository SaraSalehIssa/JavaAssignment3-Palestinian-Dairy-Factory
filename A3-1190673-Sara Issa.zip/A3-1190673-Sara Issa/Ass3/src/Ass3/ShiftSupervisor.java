package Ass3;

public class ShiftSupervisor extends Employee {

	// Data fields
	private double monthlySalary;
	private double monthlyProductionBonus;
	private int numberOfProductsNeeded;
	private int numberOfProducts;

	// Constructors and methods
	public ShiftSupervisor() {
		super();
	}

	public ShiftSupervisor(String employeeName, String employeeNumber, int year, int month, int day, Address address,
			double monthlySalary, double monthlyProductionBonus, int numberOfProductsNeeded, int numberOfProducts) {
		super(employeeName, employeeNumber, year, month, day, address);
		this.monthlySalary = monthlySalary;
		this.monthlyProductionBonus = monthlyProductionBonus;
		this.setNumberOfProductsNeeded(numberOfProductsNeeded); // this.numberOfProductsNeeded = numberOfProductsNeeded;
		this.setNumberOfProducts(numberOfProducts); // this.numberOfProducts = numberOfProducts;
	}

	public double getMonthlySalary() {
		return monthlySalary;
	}

	public void setMonthlySalary(double monthlySalary) {
		this.monthlySalary = monthlySalary;
	}
	
	// To check if the monthly salary is a negative number
	public boolean isNonNegativeMonnthlySalary() {
			if (this.getMonthlySalary() >= 0) {
				return true;
			}
			return false;
		}

	public double getMonthlyProductionBonus() {
		return monthlyProductionBonus;
	}

	// To check if the monthly production bouns is a negative number
	public void setmonthlyProductionBonus(double monthlyProductionBonus) {
		if (this.getMonthlyProductionBonus() < 0) {
			System.out.println("There is no negative number of monthly production bonus");
		}
		this.monthlyProductionBonus = monthlyProductionBonus;
	}

	public int getNumberOfProductsNeeded() {
		return numberOfProductsNeeded;
	}

	// To check if the number of product needed is a negative number
	public void setNumberOfProductsNeeded(int numberOfProductsNeeded) {
		if (this.getNumberOfProductsNeeded() < 0) {
			System.out.println("There is no negative number of number of products");
		}
		this.numberOfProductsNeeded = numberOfProductsNeeded;
	}

	public int getNumberOfProducts() {
		return numberOfProducts;
	}

	// To check if the number of products is a negative number
	public void setNumberOfProducts(int numberOfProducts) {
		if (this.getNumberOfProducts() < 0) {
			System.out.println("There is no negative number of number of products");
		}

		this.numberOfProducts = numberOfProducts;
	}

	// @Override
	public double getTotalSalary() {
		double salary = 0;
		if (numberOfProducts >= numberOfProductsNeeded) {
			salary += monthlySalary + monthlyProductionBonus;
		} else {
			salary += monthlySalary;
		}
		return salary;
	}

	@Override
	public String toString() {
		return "ShiftSupervisor: " + super.toString() + " monthlySalary=" + monthlySalary + ", monthlyProductionBonus="
				+ monthlyProductionBonus + ", numberOfProductsNeeded=" + numberOfProductsNeeded + ", numberOfProducts="
				+ numberOfProducts;
	}
}

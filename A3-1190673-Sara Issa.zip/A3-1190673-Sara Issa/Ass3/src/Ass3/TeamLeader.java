package Ass3;

public class TeamLeader extends ProductionWorker {

	// Data fields
	private double monthlyBonus;
	private double requiredTrainingHours;
	private double trainingHoursAttended;

	// Constructors and methods
	public TeamLeader() {
		super();
	}

	public TeamLeader(String employeeName, String employeeNumber, int year, int month, int day, Address address,
			int shift, double hourlyPayRate, double numberOfHoursPerMonth, double monthlyBonus,
			double requiredTrainingHours, double trainingHoursAttended) {
		super(employeeName, employeeNumber, year, month, day, address, shift, hourlyPayRate, numberOfHoursPerMonth);
		this.setMonthlyBonus(monthlyBonus); // this.monthlyBonus = monthlyBonus;
		this.setRequiredTrainingHours(requiredTrainingHours); // this.requiredTrainingHours = requiredTrainingHours;
		this.setTrainingHoursAttended(trainingHoursAttended); // this.trainingHoursAttended = trainingHoursAttended;
	}

	public double getMonthlyBonus() {
		return monthlyBonus;
	}

	// To check if the monthly bounds is a negative number
	public void setMonthlyBonus(double monthlyBonus) {
		if (this.getMonthlyBonus() < 0) {
			System.out.println("There is no negative number of month bonus");
		}
		this.monthlyBonus = monthlyBonus;
	}

	public double getRequiredTrainingHours() {
		return requiredTrainingHours;
	}

	// To check if the required training hours is a negative number
	public void setRequiredTrainingHours(double requiredTrainingHours) {
		if (this.getRequiredTrainingHours() < 0) {
			System.out.println("There is no negative number of training hours");
		}
		this.requiredTrainingHours = requiredTrainingHours;
	}

	public double getTrainingHoursAttended() {
		return trainingHoursAttended;
	}

	// To check if the training hours attended is a negative number
	public void setTrainingHoursAttended(double trainingHoursAttended) {
		if (this.getTrainingHoursAttended() < 0) {
			System.out.println("There is no negative number of training hours");
		}
		this.trainingHoursAttended = trainingHoursAttended;
	}

	@Override
	public double getTotalSalary() {
		double salary = super.getTotalSalary();
		if (trainingHoursAttended >= requiredTrainingHours) {
			salary += monthlyBonus * trainingHoursAttended / requiredTrainingHours;
		}
		return salary;
	}

	@Override
	public String toString() {
		return "TeamLeader: " + super.toString() + "monthlyBonus=" + monthlyBonus + ", requiredTrainingHours="
				+ requiredTrainingHours + ", trainingHoursAttended=" + trainingHoursAttended;
	}
}
